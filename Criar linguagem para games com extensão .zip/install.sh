#!/bin/bash

# BlueSoft Engine Script (BSES) - Script de Instalação
# Este script instala a BlueSoft Engine no sistema

set -e

echo "=== BlueSoft Engine Script (BSES) - Instalação ==="
echo

# Verificar se Python 3 está instalado
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 não encontrado. Por favor, instale Python 3 primeiro."
    exit 1
fi

echo "✅ Python 3 encontrado"

# Verificar se pip está instalado
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 não encontrado. Por favor, instale pip3 primeiro."
    exit 1
fi

echo "✅ pip3 encontrado"

# Instalar dependências Python
echo "📦 Instalando dependências Python..."
pip3 install openai

echo "✅ Dependências instaladas"

# Criar diretório de instalação
INSTALL_DIR="/usr/local/bin"
BSES_DIR="/usr/local/share/bses"

echo "📁 Criando diretórios de instalação..."
sudo mkdir -p "$BSES_DIR"

# Copiar arquivos da engine
echo "📋 Copiando arquivos da engine..."
sudo cp bses_lexer.py "$BSES_DIR/"
sudo cp bses_parser.py "$BSES_DIR/"
sudo cp bses_codegen.py "$BSES_DIR/"
sudo cp bses_compiler.py "$BSES_DIR/"
sudo cp bsesk_generator.py "$BSES_DIR/"
sudo cp game_template.html "$BSES_DIR/"

# Criar script executável
echo "🔧 Criando comando bses..."
sudo tee "$INSTALL_DIR/bses" > /dev/null << 'EOF'
#!/usr/bin/env python3
import os
import sys

# Add BSES directory to Python path
sys.path.insert(0, '/usr/local/share/bses')

# Import and run the main compiler
from bses_compiler import main

if __name__ == "__main__":
    main()
EOF

# Tornar executável
sudo chmod +x "$INSTALL_DIR/bses"

echo "✅ Instalação concluída!"
echo
echo "🎮 Para começar a usar:"
echo "  1. Crie um novo projeto: bses new meu_jogo"
echo "  2. Entre no diretório: cd meu_jogo"
echo "  3. Compile o jogo: bses compile index.html"
echo "  4. Abra index.html no navegador para jogar!"
echo
echo "📚 Para mais informações, consulte o README.md"
echo
echo "🚀 BlueSoft Engine instalada com sucesso!"
