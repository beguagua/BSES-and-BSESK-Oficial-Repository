#!/usr/bin/env python3
"""
Parser (Analisador Sintático) para BlueSoft Engine Script (BSES)
"""

from dataclasses import dataclass
from typing import List, Optional, Any, Dict, Union
from bses_lexer import Token, TokenType, BSESLexer

# AST Node Types
@dataclass
class ASTNode:
    pass

@dataclass
class Program(ASTNode):
    gameobjects: List["GameObjectDeclaration"]

@dataclass
class GameObjectDeclaration(ASTNode):
    name: str
    properties: List["PropertyDeclaration"]
    methods: List["MethodDeclaration"]

@dataclass
class PropertyDeclaration(ASTNode):
    visibility: str
    name: str
    type: str
    default_value: Optional["Expression"] = None

@dataclass
class MethodDeclaration(ASTNode):
    visibility: str
    name: str
    parameters: List["Parameter"]
    body: List["Statement"]
    return_type: Optional[str] = None

@dataclass
class Parameter(ASTNode):
    name: str
    type: str

@dataclass
class Statement(ASTNode):
    pass

@dataclass
class Expression(ASTNode):
    pass

@dataclass
class BlockStatement(Statement):
    statements: List[Statement]

@dataclass
class IfStatement(Statement):
    condition: Expression
    then_branch: Statement
    else_branch: Optional[Statement] = None

@dataclass
class WhileStatement(Statement):
    condition: Expression
    body: Statement

@dataclass
class ReturnStatement(Statement):
    value: Optional[Expression] = None

@dataclass
class ExpressionStatement(Statement):
    expression: Expression

@dataclass
class VariableDeclaration(Statement):
    name: str
    type: Optional[str]
    initializer: Optional[Expression] = None

@dataclass
class AssignmentExpression(Expression):
    target: Expression
    operator: str
    value: Expression

@dataclass
class BinaryExpression(Expression):
    left: Expression
    operator: str
    right: Expression

@dataclass
class UnaryExpression(Expression):
    operator: str
    operand: Expression

@dataclass
class CallExpression(Expression):
    callee: Expression
    arguments: List[Expression]

@dataclass
class MemberExpression(Expression):
    object: Expression
    property: str

@dataclass
class Identifier(Expression):
    name: str

@dataclass
class Literal(Expression):
    value: Any
    type: str

@dataclass
class ArrayLiteral(Expression):
    elements: List[Expression]

@dataclass
class ObjectLiteral(Expression):
    properties: Dict[str, Expression]

class BSESParser:
    def __init__(self, tokens: List[Token]):
        self.tokens = [t for t in tokens if t.type not in [TokenType.COMMENT, TokenType.NEWLINE]]
        self.current = 0
    
    def is_at_end(self) -> bool:
        return self.peek().type == TokenType.EOF
    
    def peek(self) -> Token:
        return self.tokens[self.current]
    
    def previous(self) -> Token:
        return self.tokens[self.current - 1]
    
    def advance(self) -> Token:
        if not self.is_at_end():
            self.current += 1
        return self.previous()
    
    def check(self, token_type: TokenType) -> bool:
        if self.is_at_end():
            return False
        return self.peek().type == token_type
    
    def match(self, *types: TokenType) -> bool:
        for token_type in types:
            if self.check(token_type):
                self.advance()
                return True
        return False
    
    def consume(self, token_type: TokenType, message: str) -> Token:
        if self.check(token_type):
            return self.advance()
        current_token = self.peek()
        raise SyntaxError(f"{message}. Encontrado '{current_token.value}' na linha {current_token.line}")

    def parse(self) -> Program:
        gameobjects = []
        while not self.is_at_end():
            if self.check(TokenType.GAMEOBJECT):
                gameobjects.append(self.parse_gameobject())
            else:
                self.advance()
        return Program(gameobjects)

    def parse_type(self) -> str:
        allowed_types = [TokenType.IDENTIFIER, TokenType.NUMBER_TYPE, TokenType.STRING_TYPE, TokenType.BOOLEAN_TYPE, TokenType.VECTOR2_TYPE, TokenType.VECTOR3_TYPE, TokenType.COLOR_TYPE, TokenType.ARRAY_TYPE, TokenType.MAP_TYPE, TokenType.GAMEOBJECT_TYPE]
        for token_type in allowed_types:
            if self.check(token_type):
                return self.advance().value
        current_token = self.peek()
        raise SyntaxError(f"Esperado um tipo. Encontrado '{current_token.value}' na linha {current_token.line}")

    def parse_gameobject(self) -> GameObjectDeclaration:
        self.consume(TokenType.GAMEOBJECT, "Esperado 'gameobject'")
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome do gameobject").value
        self.consume(TokenType.LBRACE, "Esperado '{'")
        properties = []
        methods = []
        while not self.check(TokenType.RBRACE) and not self.is_at_end():
            visibility = "public"
            if self.match(TokenType.PUBLIC, TokenType.PRIVATE):
                visibility = self.previous().value
            if self.check(TokenType.CONSTRUCTOR):
                methods.append(self.parse_constructor(visibility))
            elif self.check(TokenType.IDENTIFIER):
                saved_pos = self.current
                self.advance()
                if self.check(TokenType.LPAREN):
                    self.current = saved_pos
                    methods.append(self.parse_method(visibility))
                else:
                    self.current = saved_pos
                    properties.append(self.parse_property(visibility))
            else:
                self.advance()
        self.consume(TokenType.RBRACE, "Esperado '}'")
        return GameObjectDeclaration(name, properties, methods)

    def parse_property(self, visibility: str) -> PropertyDeclaration:
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome da propriedade").value
        self.consume(TokenType.COLON, "Esperado ':'")
        prop_type = self.parse_type()
        default_value = None
        if self.match(TokenType.ASSIGN):
            default_value = self.parse_expression()
        self.consume(TokenType.SEMICOLON, "Esperado ';'")
        return PropertyDeclaration(visibility, name, prop_type, default_value)

    def parse_constructor(self, visibility: str) -> MethodDeclaration:
        self.consume(TokenType.CONSTRUCTOR, "Esperado 'constructor'")
        self.consume(TokenType.LPAREN, "Esperado '('")
        parameters = self.parse_parameter_list()
        self.consume(TokenType.RPAREN, "Esperado ')'")
        body = self.parse_block()
        return MethodDeclaration(visibility, "constructor", parameters, body)

    def parse_method(self, visibility: str) -> MethodDeclaration:
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome do método").value
        self.consume(TokenType.LPAREN, "Esperado '('")
        parameters = self.parse_parameter_list()
        self.consume(TokenType.RPAREN, "Esperado ')'")
        return_type = None
        if self.match(TokenType.COLON):
            return_type = self.parse_type()
        body = self.parse_block()
        return MethodDeclaration(visibility, name, parameters, body, return_type)

    def parse_parameter_list(self) -> List[Parameter]:
        parameters = []
        if not self.check(TokenType.RPAREN):
            parameters.append(self.parse_parameter())
            while self.match(TokenType.COMMA):
                parameters.append(self.parse_parameter())
        return parameters

    def parse_parameter(self) -> Parameter:
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome do parâmetro").value
        self.consume(TokenType.COLON, "Esperado ':'")
        param_type = self.parse_type()
        return Parameter(name, param_type)

    def parse_block(self) -> List[Statement]:
        self.consume(TokenType.LBRACE, "Esperado '{'")
        statements = []
        while not self.check(TokenType.RBRACE) and not self.is_at_end():
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
        self.consume(TokenType.RBRACE, "Esperado '}'")
        return statements

    def parse_statement(self) -> Optional[Statement]:
        if self.match(TokenType.IF): return self.parse_if_statement()
        if self.match(TokenType.WHILE): return self.parse_while_statement()
        if self.match(TokenType.RETURN): return self.parse_return_statement()
        if self.match(TokenType.LET): return self.parse_variable_declaration()
        if self.check(TokenType.LBRACE): return BlockStatement(self.parse_block())
        expr = self.parse_expression()
        self.match(TokenType.SEMICOLON)
        return ExpressionStatement(expr)

    def parse_if_statement(self) -> IfStatement:
        self.consume(TokenType.LPAREN, "Esperado '(' após 'if'")
        condition = self.parse_expression()
        self.consume(TokenType.RPAREN, "Esperado ')' após condição")
        then_branch = self.parse_statement()
        else_branch = None
        if self.match(TokenType.ELSE):
            else_branch = self.parse_statement()
        return IfStatement(condition, then_branch, else_branch)

    def parse_while_statement(self) -> WhileStatement:
        self.consume(TokenType.LPAREN, "Esperado '(' após 'while'")
        condition = self.parse_expression()
        self.consume(TokenType.RPAREN, "Esperado ')' após condição")
        body = self.parse_statement()
        return WhileStatement(condition, body)

    def parse_return_statement(self) -> ReturnStatement:
        value = None
        if not self.check(TokenType.SEMICOLON):
            value = self.parse_expression()
        self.match(TokenType.SEMICOLON)
        return ReturnStatement(value)

    def parse_variable_declaration(self) -> VariableDeclaration:
        name = self.consume(TokenType.IDENTIFIER, "Esperado nome da variável").value
        var_type = None
        if self.match(TokenType.COLON):
            var_type = self.parse_type()
        initializer = None
        if self.match(TokenType.ASSIGN):
            initializer = self.parse_expression()
        self.match(TokenType.SEMICOLON)
        return VariableDeclaration(name, var_type, initializer)

    def parse_expression(self) -> Expression:
        return self.parse_assignment()

    def parse_assignment(self) -> Expression:
        expr = self.parse_logical_or()
        if self.match(TokenType.ASSIGN, TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN, TokenType.MULTIPLY_ASSIGN, TokenType.DIVIDE_ASSIGN):
            operator = self.previous().value
            value = self.parse_assignment()
            if isinstance(expr, (Identifier, MemberExpression)):
                return AssignmentExpression(expr, operator, value)
            raise SyntaxError("Alvo de atribuição inválido.")
        return expr

    def parse_logical_or(self) -> Expression:
        expr = self.parse_logical_and()
        while self.match(TokenType.OR):
            operator = self.previous().value
            right = self.parse_logical_and()
            expr = BinaryExpression(expr, operator, right)
        return expr

    def parse_logical_and(self) -> Expression:
        expr = self.parse_equality()
        while self.match(TokenType.AND):
            operator = self.previous().value
            right = self.parse_equality()
            expr = BinaryExpression(expr, operator, right)
        return expr

    def parse_equality(self) -> Expression:
        expr = self.parse_comparison()
        while self.match(TokenType.EQUALS, TokenType.NOT_EQUALS):
            operator = self.previous().value
            right = self.parse_comparison()
            expr = BinaryExpression(expr, operator, right)
        return expr

    def parse_comparison(self) -> Expression:
        expr = self.parse_term()
        while self.match(TokenType.GREATER_THAN, TokenType.GREATER_EQUAL, TokenType.LESS_THAN, TokenType.LESS_EQUAL):
            operator = self.previous().value
            right = self.parse_term()
            expr = BinaryExpression(expr, operator, right)
        return expr

    def parse_term(self) -> Expression:
        expr = self.parse_factor()
        while self.match(TokenType.MINUS, TokenType.PLUS):
            operator = self.previous().value
            right = self.parse_factor()
            expr = BinaryExpression(expr, operator, right)
        return expr

    def parse_factor(self) -> Expression:
        expr = self.parse_unary()
        while self.match(TokenType.DIVIDE, TokenType.MULTIPLY, TokenType.MODULO):
            operator = self.previous().value
            right = self.parse_unary()
            expr = BinaryExpression(expr, operator, right)
        return expr

    def parse_unary(self) -> Expression:
        if self.match(TokenType.NOT, TokenType.MINUS):
            operator = self.previous().value
            right = self.parse_unary()
            return UnaryExpression(operator, right)
        return self.parse_call()

    def parse_call(self) -> Expression:
        expr = self.parse_primary()
        while True:
            if self.match(TokenType.LPAREN):
                expr = self.finish_call(expr)
            elif self.match(TokenType.DOT):
                name = self.consume(TokenType.IDENTIFIER, "Esperado nome da propriedade").value
                expr = MemberExpression(expr, name)
            else:
                break
        return expr

    def finish_call(self, callee: Expression) -> CallExpression:
        arguments = []
        if not self.check(TokenType.RPAREN):
            arguments.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                arguments.append(self.parse_expression())
        self.consume(TokenType.RPAREN, "Esperado ')' após argumentos")
        return CallExpression(callee, arguments)

    def parse_primary(self) -> Expression:
        if self.match(TokenType.TRUE): return Literal(True, "boolean")
        if self.match(TokenType.FALSE): return Literal(False, "boolean")
        if self.match(TokenType.NULL): return Literal(None, "null")
        if self.match(TokenType.NUMBER): return Literal(float(self.previous().value) if '.' in self.previous().value else int(self.previous().value), "number")
        if self.match(TokenType.STRING): return Literal(self.previous().value, "string")
        if self.match(TokenType.IDENTIFIER): return Identifier(self.previous().value)
        if self.match(TokenType.LPAREN):
            expr = self.parse_expression()
            self.consume(TokenType.RPAREN, "Esperado ')' após expressão")
            return expr
        if self.match(TokenType.LBRACKET): return self.parse_array_literal()
        if self.match(TokenType.LBRACE): return self.parse_object_literal()
        if self.check(TokenType.VECTOR2_TYPE) or self.check(TokenType.VECTOR3_TYPE) or self.check(TokenType.COLOR_TYPE):
            constructor_name = self.advance().value
            self.consume(TokenType.LPAREN, f"Esperado '(' após {constructor_name}")
            arguments = []
            if not self.check(TokenType.RPAREN):
                arguments.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    arguments.append(self.parse_expression())
            self.consume(TokenType.RPAREN, "Esperado ')' após argumentos")
            return CallExpression(Identifier(constructor_name), arguments)
        raise SyntaxError(f"Expressão inesperada: {self.peek().value} na linha {self.peek().line}")

    def parse_array_literal(self) -> ArrayLiteral:
        elements = []
        if not self.check(TokenType.RBRACKET):
            elements.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                elements.append(self.parse_expression())
        self.consume(TokenType.RBRACKET, "Esperado ']'")
        return ArrayLiteral(elements)

    def parse_object_literal(self) -> ObjectLiteral:
        properties = {}
        if not self.check(TokenType.RBRACE):
            key = self.consume(TokenType.STRING, "Esperado chave string").value
            self.consume(TokenType.COLON, "Esperado ':'")
            value = self.parse_expression()
            properties[key] = value
            while self.match(TokenType.COMMA):
                key = self.consume(TokenType.STRING, "Esperado chave string").value
                self.consume(TokenType.COLON, "Esperado ':'")
                value = self.parse_expression()
                properties[key] = value
        self.consume(TokenType.RBRACE, "Esperado '}'")
        return ObjectLiteral(properties)

def main():
    test_code = '''
    gameobject Player {
        public position: Vector2;
        private health: number = 100;
        constructor(startPos: Vector2) {
            this.position = startPos;
        }
        public onUpdate(deltaTime: number) {
            if (Input.isPressed("right")) {
                this.position.x += 200 * deltaTime;
            }
        }
    }
    '''
    lexer = BSESLexer(test_code)
    tokens = lexer.tokenize()
    parser = BSESParser(tokens)
    ast = parser.parse()
    print("AST gerada com sucesso!")
    print(f"Gameobjects encontrados: {len(ast.gameobjects)}")
    for go in ast.gameobjects:
        print(f"  - {go.name}: {len(go.properties)} propriedades, {len(go.methods)} métodos")

if __name__ == "__main__":
    main()

