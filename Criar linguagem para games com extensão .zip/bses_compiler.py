#!/usr/bin/env python3
"""
Compilador Principal BlueSoft Engine Script (BSES)
"""

import os
import sys
import argparse
from typing import List, Optional
from bses_lexer import BSESLexer
from bses_parser import BSESParser
from bses_codegen import BSESCodeGenerator
from bsesk_generator import BSESKGenerator

class BSESCompiler:
    def __init__(self):
        self.template_path = "game_template.html"
        self.output_placeholder = "// GENERATED_CODE_PLACEHOLDER"
    
    def find_bses_files(self, directory: str) -> List[str]:
        """Encontra todos os arquivos .bses no diretório"""
        bses_files = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith('.bses'):
                    bses_files.append(os.path.join(root, file))
        return bses_files
    
    def compile_bses_file(self, filepath: str) -> str:
        """Compila um único arquivo .bses para JavaScript"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            # Lexical analysis
            lexer = BSESLexer(source_code)
            tokens = lexer.tokenize()
            
            # Syntax analysis
            parser = BSESParser(tokens)
            ast = parser.parse()
            
            # Code generation
            codegen = BSESCodeGenerator()
            js_code = codegen.generate(ast)
            
            return js_code
            
        except Exception as e:
            raise Exception(f"Erro ao compilar {filepath}: {e}")
    
    def compile_project(self, project_dir: str, output_file: str) -> bool:
        """Compila um projeto BSES completo para HTML"""
        try:
            print(f"Compilando projeto: {project_dir}")
            
            # Find all .bses files
            bses_files = self.find_bses_files(project_dir)
            
            if not bses_files:
                print("Nenhum arquivo .bses encontrado no projeto")
                return False
            
            print(f"Arquivos encontrados: {len(bses_files)}")
            for file in bses_files:
                print(f"  - {file}")
            
            # Compile all .bses files
            compiled_code_parts = []
            for bses_file in bses_files:
                print(f"Compilando: {bses_file}")
                js_code = self.compile_bses_file(bses_file)
                compiled_code_parts.append(f"// From: {os.path.basename(bses_file)}")
                compiled_code_parts.append(js_code)
                compiled_code_parts.append("")
            
            # Combine all compiled code
            combined_code = "\n".join(compiled_code_parts)
            
            # Load HTML template
            template_path = os.path.join(os.path.dirname(__file__), self.template_path)
            if not os.path.exists(template_path):
                # Try current directory
                template_path = self.template_path
                if not os.path.exists(template_path):
                    raise Exception(f"Template HTML não encontrado: {self.template_path}")
            
            with open(template_path, 'r', encoding='utf-8') as f:
                html_template = f.read()
            
            # Replace placeholder with compiled code
            final_html = html_template.replace(self.output_placeholder, combined_code)
            
            # Write output file
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(final_html)
            
            print(f"Compilação concluída: {output_file}")
            return True
            
        except Exception as e:
            print(f"Erro durante a compilação: {e}")
            return False
    
    def process_bsesk_file(self, bsesk_file: str) -> bool:
        """Processa um arquivo .bsesk e gera o .bses correspondente"""
        try:
            generator = BSESKGenerator()
            return generator.process_bsesk_file(bsesk_file)
        except Exception as e:
            print(f"Erro ao processar arquivo .bsesk: {e}")
            return False

def create_sample_project(project_name: str):
    """Cria um projeto de exemplo"""
    project_dir = project_name
    os.makedirs(project_dir, exist_ok=True)
    
    # Create main.bses
    main_bses = f"""gameobject Player {{
    public position: Vector2;
    public speed: number = 200;
    private health: number = 100;
    
    constructor(startPos: Vector2) {{
        this.position = startPos;
        this.tag = "Player";
        this.size = new Vector2(40, 40);
        print("Player criado!");
    }}
    
    public onUpdate(deltaTime: number) {{
        // Movimento com WASD ou setas
        if (Input.isPressed("right") || Input.isPressed("d")) {{
            this.position.x += this.speed * deltaTime;
        }}
        if (Input.isPressed("left") || Input.isPressed("a")) {{
            this.position.x -= this.speed * deltaTime;
        }}
        if (Input.isPressed("up") || Input.isPressed("w")) {{
            this.position.y -= this.speed * deltaTime;
        }}
        if (Input.isPressed("down") || Input.isPressed("s")) {{
            this.position.y += this.speed * deltaTime;
        }}
        
        // Manter dentro da tela
        if (this.position.x < 0) this.position.x = 0;
        if (this.position.y < 0) this.position.y = 0;
        if (this.position.x > 760) this.position.x = 760;
        if (this.position.y > 560) this.position.y = 560;
    }}
    
    public onDraw(ctx) {{
        Graphics.drawRectangle(this.position.x, this.position.y, this.size.x, this.size.y, new Color(100, 150, 255));
    }}
    
    public onCollision(other: GameObject) {{
        if (other.tag == "Enemy") {{
            print("Game Over!");
            Game.destroy(this);
        }}
    }}
}}

gameobject Enemy {{
    public position: Vector2;
    public speed: number = 100;
    
    constructor(startPos: Vector2) {{
        this.position = startPos;
        this.tag = "Enemy";
        this.size = new Vector2(30, 30);
    }}
    
    public onUpdate(deltaTime: number) {{
        // Move para baixo
        this.position.y += this.speed * deltaTime;
        
        // Remove se sair da tela
        if (this.position.y > 650) {{
            Game.destroy(this);
        }}
    }}
    
    public onDraw(ctx) {{
        Graphics.drawRectangle(this.position.x, this.position.y, this.size.x, this.size.y, new Color(255, 100, 100));
    }}
}}"""
    
    with open(os.path.join(project_dir, "main.bses"), 'w', encoding='utf-8') as f:
        f.write(main_bses)
    
    # Create sample .bsesk file
    sample_bsesk = """sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Crie um jogo onde o jogador é um quadrado azul que pode se mover com as setas do teclado. Inimigos vermelhos caem do topo da tela. Se o jogador tocar em um inimigo, o jogo termina. O objetivo é sobreviver o máximo de tempo possível."""
    
    with open(os.path.join(project_dir, "sample_game.bsesk"), 'w', encoding='utf-8') as f:
        f.write(sample_bsesk)
    
    print(f"Projeto de exemplo criado em: {project_dir}")
    print("Arquivos criados:")
    print(f"  - {project_dir}/main.bses")
    print(f"  - {project_dir}/sample_game.bsesk")
    print()
    print("Para compilar o projeto:")
    print(f"  cd {project_dir}")
    print(f"  bses compile index.html")

def main():
    parser = argparse.ArgumentParser(description='BlueSoft Engine Script Compiler')
    subparsers = parser.add_subparsers(dest='command', help='Comandos disponíveis')
    
    # Compile command
    compile_parser = subparsers.add_parser('compile', help='Compila projeto BSES para HTML')
    compile_parser.add_argument('output', help='Arquivo HTML de saída')
    compile_parser.add_argument('--project', '-p', default='.', help='Diretório do projeto (padrão: diretório atual)')
    
    # Generate command (for .bsesk files)
    generate_parser = subparsers.add_parser('generate', help='Gera código BSES a partir de arquivo .bsesk')
    generate_parser.add_argument('bsesk_file', help='Arquivo .bsesk de entrada')
    generate_parser.add_argument('--output', '-o', help='Arquivo .bses de saída')
    
    # New project command
    new_parser = subparsers.add_parser('new', help='Cria um novo projeto de exemplo')
    new_parser.add_argument('project_name', help='Nome do projeto')
    
    # Version command
    version_parser = subparsers.add_parser('version', help='Mostra a versão do compilador')
    
    args = parser.parse_args()
    
    if args.command == 'compile':
        compiler = BSESCompiler()
        success = compiler.compile_project(args.project, args.output)
        sys.exit(0 if success else 1)
    
    elif args.command == 'generate':
        compiler = BSESCompiler()
        success = compiler.process_bsesk_file(args.bsesk_file)
        sys.exit(0 if success else 1)
    
    elif args.command == 'new':
        create_sample_project(args.project_name)
        sys.exit(0)
    
    elif args.command == 'version':
        print("BlueSoft Engine Script Compiler v1.0.0")
        sys.exit(0)
    
    else:
        parser.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()
