# Especificação da Linguagem BlueSoft Engine Script (BSES)

## 1. Visão Geral

BlueSoft Engine Script (BSES) é uma linguagem de script de alto nível, orientada a objetos, projetada especificamente para o desenvolvimento de jogos. A sintaxe busca ser intuitiva e limpa, inspirada em linguagens modernas como Python e JavaScript, mas com construções e tipos de dados nativos para operações de jogos.

A linguagem será compilada para uma representação de bytecode intermediária e executada em uma máquina virtual (VM) otimizada, que será integrada diretamente à BlueSoft Engine.

## 2. Tipos de Dados Primitivos

- `number`: Representa tanto inteiros quanto números de ponto flutuante de 64 bits.
- `string`: Sequência de caracteres Unicode.
- `boolean`: `true` ou `false`.
- `null`: Representa a ausência de valor.

## 3. Tipos de Dados Compostos e de Engine

- `Vector2`: Objeto com propriedades `x` e `y`. Ex: `let pos = Vector2(100, 200);`
- `Vector3`: Objeto com propriedades `x`, `y`, e `z`.
- `Color`: Objeto com propriedades `r`, `g`, `b`, e `a` (alfa). Ex: `let red = Color(255, 0, 0, 255);`
- `Array`: Coleção ordenada de valores. Ex: `let items = [1, "espada", true];`
- `Map`: Coleção de pares chave-valor. Ex: `let stats = {"hp": 100, "mana": 50};`

## 4. Estrutura de um Script

Um script `.bses` é composto por definições de `GameObject`s. Um `GameObject` é a unidade fundamental de qualquer item em um jogo (personagem, inimigo, item, etc.).

```bses
gameobject Player {
    // Propriedades
    public position: Vector2;
    public speed: number = 200;
    private health: number = 100;

    // Método construtor, chamado na criação do objeto
    constructor(startPos: Vector2) {
        this.position = startPos;
        print("Player criado em: " + this.position);
    }

    // Método chamado a cada frame do jogo
    public onUpdate(deltaTime: number) {
        if (Input.isPressed("right")) {
            this.position.x += this.speed * deltaTime;
        }
        if (Input.isPressed("left")) {
            this.position.x -= this.speed * deltaTime;
        }
    }

    // Método chamado quando ocorre uma colisão
    public onCollision(other: GameObject) {
        if (other.tag == "Enemy") {
            this.takeDamage(10);
        }
    }

    private takeDamage(amount: number) {
        this.health -= amount;
        if (this.health <= 0) {
            Game.destroy(this);
        }
    }
}
```

## 5. Funções e Métodos de Ciclo de Vida

- `constructor()`: Chamado uma vez quando o objeto é instanciado.
- `onUpdate(deltaTime: number)`: Chamado a cada frame. `deltaTime` é o tempo em segundos desde o último frame.
- `onDraw(g: GraphicsContext)`: Chamado a cada frame para desenhar o objeto. Permite desenhar formas, sprites, etc.
- `onCollision(other: GameObject)`: Chamado quando o colisor do objeto se sobrepõe a outro.

## 6. API da Engine (Módulos Globais)

- `Game`: Controla o estado geral do jogo.
  - `Game.loadScene(sceneName: string)`
  - `Game.destroy(object: GameObject)`
  - `Game.instantiate(objectType: string, position: Vector2)`
- `Input`: Gerencia a entrada do usuário.
  - `Input.isPressed(key: string): boolean`
  - `Input.isJustPressed(key: string): boolean`
  - `Input.getMousePosition(): Vector2`
- `Graphics`: Funções de desenho de baixo nível.
  - `Graphics.drawSprite(spriteName: string, position: Vector2)`
  - `Graphics.drawRectangle(x: number, y: number, width: number, height: number, color: Color)`
- `Audio`: Controla a reprodução de som.
  - `Audio.playSound(soundName: string)`
  - `Audio.playMusic(musicName: string, loop: boolean)`

## 7. Sistema de Geração BSESK (.bsesk)

O arquivo `.bsesk` será um arquivo de texto simples contendo:
1.  A chave da API da OpenAI na primeira linha.
2.  Uma descrição em linguagem natural do jogo desejado nas linhas seguintes.

O sistema `bsesk-generator` irá:
1.  Ler a chave da API e a descrição.
2.  Construir um prompt para a API da OpenAI, instruindo-a a gerar o código do jogo em formato `.bses`, seguindo a especificação definida neste documento.
3.  Salvar o código `.bses` resultante em um arquivo, pronto para ser executado pela BlueSoft Engine.

### Exemplo de `.bsesk`:

```
sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Crie um jogo onde o jogador é um círculo azul. Ele pode se mover para a esquerda e para a direita. Inimigos, que são quadrados vermelhos, caem do topo da tela. Se o jogador colidir com um inimigo, o jogo termina.
```

Este processo abstrai toda a codificação para o usuário final, permitindo a criação de protótipos rápidos baseados em ideias.

