_# BlueSoft Engine Script (BSES)_

BSES é uma linguagem de programação e engine de jogos projetada para ser simples, poderosa e divertida. Com ela, você pode criar jogos 2D para a web usando uma sintaxe moderna e intuitiva.

Este projeto inclui duas ferramentas principais:

1.  **BlueSoft Engine Script (.bses)**: A linguagem de script principal para desenvolvimento de jogos.
2.  **BlueSoft Engine Script for Kids (.bsesk)**: Uma ferramenta revolucionária que permite criar jogos a partir de descrições em linguagem natural, usando o poder da IA da OpenAI.

## Visão Geral da Arquitetura

A engine funciona compilando seus arquivos `.bses` para JavaScript de alta performance, que é então injetado em um template HTML5 para criar um jogo web completo e executável. O processo é totalmente automatizado pelo comando `bses`.

-   **Lexer (`bses_lexer.py`)**: Converte o código BSES em uma sequência de tokens.
-   **Parser (`bses_parser.py`)**: Cria uma Árvore de Sintaxe Abstrata (AST) a partir dos tokens.
-   **Code Generator (`bses_codegen.py`)**: Transforma a AST em código JavaScript otimizado.
-   **Compiler (`bses_compiler.py`)**: Orquestra todo o processo de compilação.
-   **Runtime (em `game_template.html`)**: A engine JavaScript que executa o jogo no navegador, gerenciando o loop de jogo, renderização, física e entrada.

## Como Começar

Para começar a usar a BlueSoft Engine, você pode criar um novo projeto de exemplo.

### 1. Crie um Novo Projeto

Use o comando `new` para gerar uma estrutura de projeto básica:

```bash
./bses new meu_primeiro_jogo
```

Isso criará um diretório chamado `meu_primeiro_jogo` com os seguintes arquivos:

-   `main.bses`: O arquivo principal do seu jogo, com exemplos de `gameobject`s para um jogador e um inimigo.
-   `sample_game.bsesk`: Um arquivo de exemplo para você testar a geração de jogos com IA.

### 2. Entendendo o Código `.bses`

Abra o arquivo `main.bses`. Você verá a definição de `gameobject`s, que são os blocos de construção de qualquer entidade no seu jogo.

```bses
gameobject Player {
    public position: Vector2;
    public speed: number = 200;

    constructor(startPos: Vector2) {
        this.position = startPos;
        this.tag = "Player";
    }

    public onUpdate(deltaTime: number) {
        if (Input.isPressed("right")) {
            this.position.x += this.speed * deltaTime;
        }
    }
}
```

### 3. Compile o Jogo

Navegue até o diretório do seu projeto e use o comando `compile` para transformar seu código BSES em um jogo HTML jogável.

```bash
cd meu_primeiro_jogo/
../bses compile index.html
```

Isso irá:
1.  Encontrar e compilar todos os arquivos `.bses` no diretório.
2.  Gerar um único arquivo `index.html` contendo toda a lógica do jogo.

Agora, basta abrir o `index.html` em qualquer navegador web moderno para jogar!

## Criando Jogos com IA (.bsesk)

A BSESK permite que você descreva seu jogo em português e deixe a IA escrever o código para você.

### 1. Edite o Arquivo `.bsesk`

Abra o arquivo `sample_game.bsesk` no seu projeto. Ele terá o seguinte formato:

```
sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Crie um jogo onde o jogador é um círculo azul que se move com as setas. Inimigos, que são quadrados vermelhos, caem do topo da tela. Se o jogador colidir com um inimigo, o jogo termina.
```

### 2. Adicione sua Chave da API OpenAI

Substitua `sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` pela sua chave de API real da OpenAI.

> **Aviso**: Sua chave de API é um segredo. Não a compartilhe publicamente nem a envie para sistemas de controle de versão.

### 3. Gere o Código do Jogo

Use o comando `generate` para que a IA crie um novo arquivo `.bses` baseado na sua descrição:

```bash
../bses generate sample_game.bsesk
```

Isso criará um arquivo `sample_game.bses`. Agora você pode compilar seu projeto novamente para incluir o novo jogo:

```bash
../bses compile jogo_da_ia.html
```

## Referência da API da Engine

Dentro dos seus scripts `.bses`, você tem acesso a uma API global para controlar a engine.

| Módulo      | Função                                       | Descrição                                               |
| :---------- | :------------------------------------------- | :------------------------------------------------------ |
| `Game`      | `instantiate(Tipo, posicao)`                 | Cria uma nova instância de um `gameobject`.             |
|             | `destroy(objeto)`                            | Remove um `gameobject` do jogo.                         |
| `Input`     | `isPressed(tecla)`                           | Verifica se uma tecla está pressionada (`"left"`, `"w"`). |
|             | `getMousePosition()`                         | Retorna um `Vector2` com a posição do mouse.            |
| `Graphics`  | `drawRectangle(x, y, w, h, cor)`             | Desenha um retângulo na tela.                           |
|             | `drawCircle(x, y, raio, cor)`                | Desenha um círculo na tela.                             |
| `Audio`     | `playSound(nomeDoSom)`                       | Toca um efeito sonoro.                                  |
| `print`     | `print(mensagem)`                            | Exibe uma mensagem no console do navegador.             |

## Próximos Passos

-   **Explore a API**: Adicione mais inimigos, crie um sistema de pontuação ou implemente novas mecânicas.
-   **Crie seus próprios jogos**: Use o `bsesk` para prototipar ideias rapidamente.
-   **Expanda a Engine**: O código-fonte completo está disponível para você modificar e adicionar novos recursos.

