#!/usr/bin/env python3
"""
Lexer (Analisador Léxico) para BlueSoft Engine Script (BSES)
"""

import re
from enum import Enum
from dataclasses import dataclass
from typing import List, Optional, Iterator

class TokenType(Enum):
    # Literais
    NUMBER = "NUMBER"
    STRING = "STRING"
    BOOLEAN = "BOOLEAN"
    NULL = "NULL"
    
    # Identificadores
    IDENTIFIER = "IDENTIFIER"
    
    # Palavras-chave
    GAMEOBJECT = "gameobject"
    PUBLIC = "public"
    PRIVATE = "private"
    CONSTRUCTOR = "constructor"
    IF = "if"
    ELSE = "else"
    WHILE = "while"
    FOR = "for"
    RETURN = "return"
    LET = "let"
    TRUE = "true"
    FALSE = "false"
    
    # Tipos
    NUMBER_TYPE = "number"
    STRING_TYPE = "string"
    BOOLEAN_TYPE = "boolean"
    VECTOR2_TYPE = "Vector2"
    VECTOR3_TYPE = "Vector3"
    COLOR_TYPE = "Color"
    ARRAY_TYPE = "Array"
    MAP_TYPE = "Map"
    GAMEOBJECT_TYPE = "GameObject"
    
    # Operadores
    PLUS = "+"
    MINUS = "-"
    MULTIPLY = "*"
    DIVIDE = "/"
    MODULO = "%"
    ASSIGN = "="
    EQUALS = "=="
    NOT_EQUALS = "!="
    LESS_THAN = "<"
    GREATER_THAN = ">"
    LESS_EQUAL = "<="
    GREATER_EQUAL = ">="
    AND = "&&"
    OR = "||"
    NOT = "!"

    # Atribuição Composta
    PLUS_ASSIGN = "+="
    MINUS_ASSIGN = "-="
    MULTIPLY_ASSIGN = "*="
    DIVIDE_ASSIGN = "/="
    
    # Delimitadores
    SEMICOLON = ";"
    COMMA = ","
    DOT = "."
    COLON = ":"
    
    # Parênteses e chaves
    LPAREN = "("
    RPAREN = ")"
    LBRACE = "{"
    RBRACE = "}"
    LBRACKET = "["
    RBRACKET = "]"
    
    # Especiais
    NEWLINE = "NEWLINE"
    EOF = "EOF"
    COMMENT = "COMMENT"

@dataclass
class Token:
    type: TokenType
    value: str
    line: int
    column: int

class BSESLexer:
    def __init__(self, source_code: str):
        self.source = source_code
        self.position = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        
        self.keywords = {
            'gameobject': TokenType.GAMEOBJECT,
            'public': TokenType.PUBLIC,
            'private': TokenType.PRIVATE,
            'constructor': TokenType.CONSTRUCTOR,
            'if': TokenType.IF,
            'else': TokenType.ELSE,
            'while': TokenType.WHILE,
            'for': TokenType.FOR,
            'return': TokenType.RETURN,
            'let': TokenType.LET,
            'true': TokenType.TRUE,
            'false': TokenType.FALSE,
            'null': TokenType.NULL,
            'number': TokenType.NUMBER_TYPE,
            'string': TokenType.STRING_TYPE,
            'boolean': TokenType.BOOLEAN_TYPE,
            'Vector2': TokenType.VECTOR2_TYPE,
            'Vector3': TokenType.VECTOR3_TYPE,
            'Color': TokenType.COLOR_TYPE,
            'Array': TokenType.ARRAY_TYPE,
            'Map': TokenType.MAP_TYPE,
            'GameObject': TokenType.GAMEOBJECT_TYPE,
        }
        
        self.two_char_operators = {
            '==': TokenType.EQUALS,
            '!=': TokenType.NOT_EQUALS,
            '<=': TokenType.LESS_EQUAL,
            '>=': TokenType.GREATER_EQUAL,
            '&&': TokenType.AND,
            '||': TokenType.OR,
            '+=': TokenType.PLUS_ASSIGN,
            '-=': TokenType.MINUS_ASSIGN,
            '*=': TokenType.MULTIPLY_ASSIGN,
            '/=': TokenType.DIVIDE_ASSIGN,
        }
        
        self.single_char_operators = {
            '+': TokenType.PLUS,
            '-': TokenType.MINUS,
            '*': TokenType.MULTIPLY,
            '/': TokenType.DIVIDE,
            '%': TokenType.MODULO,
            '=': TokenType.ASSIGN,
            '<': TokenType.LESS_THAN,
            '>': TokenType.GREATER_THAN,
            '!': TokenType.NOT,
            ';': TokenType.SEMICOLON,
            ',': TokenType.COMMA,
            '.': TokenType.DOT,
            ':': TokenType.COLON,
            '(': TokenType.LPAREN,
            ')': TokenType.RPAREN,
            '{': TokenType.LBRACE,
            '}': TokenType.RBRACE,
            '[': TokenType.LBRACKET,
            ']': TokenType.RBRACKET,
        }
    
    def current_char(self) -> Optional[str]:
        if self.position >= len(self.source):
            return None
        return self.source[self.position]
    
    def peek_char(self, offset: int = 1) -> Optional[str]:
        peek_pos = self.position + offset
        if peek_pos >= len(self.source):
            return None
        return self.source[peek_pos]
    
    def advance(self) -> None:
        if self.position < len(self.source) and self.source[self.position] == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        self.position += 1
    
    def skip_whitespace(self) -> None:
        while self.current_char() and self.current_char() in ' \t\r':
            self.advance()
    
    def read_number(self) -> Token:
        start_line, start_column = self.line, self.column
        number_str = ""
        
        while self.current_char() and (self.current_char().isdigit() or self.current_char() == '.'):
            number_str += self.current_char()
            self.advance()
        
        return Token(TokenType.NUMBER, number_str, start_line, start_column)
    
    def read_string(self) -> Token:
        start_line, start_column = self.line, self.column
        quote_char = self.current_char()
        self.advance()
        
        string_value = ""
        while self.current_char() and self.current_char() != quote_char:
            if self.current_char() == '\\':
                self.advance()
                if self.current_char() == 'n': string_value += '\n'
                elif self.current_char() == 't': string_value += '\t'
                elif self.current_char() == 'r': string_value += '\r'
                elif self.current_char() == '\\': string_value += '\\'
                elif self.current_char() == quote_char: string_value += quote_char
                else: string_value += self.current_char()
                self.advance()
            else:
                string_value += self.current_char()
                self.advance()
        
        if self.current_char() == quote_char:
            self.advance()
        
        return Token(TokenType.STRING, string_value, start_line, start_column)
    
    def read_identifier(self) -> Token:
        start_line, start_column = self.line, self.column
        identifier = ""
        
        while (self.current_char() and (self.current_char().isalnum() or self.current_char() == '_')):
            identifier += self.current_char()
            self.advance()
        
        token_type = self.keywords.get(identifier, TokenType.IDENTIFIER)
        
        if token_type == TokenType.TRUE: return Token(TokenType.BOOLEAN, "true", start_line, start_column)
        elif token_type == TokenType.FALSE: return Token(TokenType.BOOLEAN, "false", start_line, start_column)
        
        return Token(token_type, identifier, start_line, start_column)
    
    def read_comment(self) -> Token:
        start_line, start_column = self.line, self.column
        comment = ""
        self.advance()
        self.advance()
        
        while self.current_char() and self.current_char() != '\n':
            comment += self.current_char()
            self.advance()
        
        return Token(TokenType.COMMENT, comment, start_line, start_column)
    
    def tokenize(self) -> List[Token]:
        while self.position < len(self.source):
            self.skip_whitespace()
            
            if not self.current_char(): break
            
            char = self.current_char()
            
            if char == '\n':
                self.tokens.append(Token(TokenType.NEWLINE, char, self.line, self.column))
                self.advance()
                continue
            
            if char == '/' and self.peek_char() == '/':
                self.tokens.append(self.read_comment())
                continue
            
            if char.isdigit():
                self.tokens.append(self.read_number())
                continue
            
            if char in '"\'':
                self.tokens.append(self.read_string())
                continue
            
            if char.isalpha() or char == '_':
                self.tokens.append(self.read_identifier())
                continue
            
            two_char = char + (self.peek_char() or '')
            if two_char in self.two_char_operators:
                self.tokens.append(Token(self.two_char_operators[two_char], two_char, self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if char in self.single_char_operators:
                self.tokens.append(Token(self.single_char_operators[char], char, self.line, self.column))
                self.advance()
                continue
            
            raise SyntaxError(f"Caractere desconhecido '{char}' na linha {self.line}, coluna {self.column}")
        
        self.tokens.append(Token(TokenType.EOF, "", self.line, self.column))
        return self.tokens

def main():
    test_code = '''
    gameobject Player {
        public position: Vector2;
        private health: number = 100;
        
        constructor(startPos: Vector2) {
            this.position = startPos;
            print("Player criado!");
        }
        
        public onUpdate(deltaTime: number) {
            if (Input.isPressed("right")) {
                this.position.x += 200 * deltaTime;
            }
        }
    }
    '''
    
    lexer = BSESLexer(test_code)
    tokens = lexer.tokenize()
    
    for token in tokens:
        if token.type not in [TokenType.NEWLINE, TokenType.COMMENT]:
            print(f"{token.type.value:15} | {token.value:20} | Linha {token.line}, Coluna {token.column}")

if __name__ == "__main__":
    main()

