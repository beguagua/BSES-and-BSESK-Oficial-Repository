# Documentação Técnica - BlueSoft Engine Script (BSES)

## Arquitetura do Sistema

A BlueSoft Engine Script é composta por vários componentes que trabalham em conjunto para compilar código BSES em jogos HTML5 executáveis.

### Componentes Principais

#### 1. Analisador Léxico (`bses_lexer.py`)
Responsável por converter o código fonte BSES em uma sequência de tokens.

**Funcionalidades:**
- Reconhecimento de palavras-chave (`gameobject`, `public`, `private`, etc.)
- Identificação de tipos nativos (`Vector2`, `Vector3`, `Color`)
- Processamento de operadores (incluindo atribuição composta `+=`, `-=`, etc.)
- Tratamento de strings, números e comentários

**Tokens Suportados:**
- Literais: `NUMBER`, `STRING`, `BOOLEAN`, `NULL`
- Palavras-chave: `gameobject`, `constructor`, `public`, `private`
- Tipos: `Vector2`, `Vector3`, `Color`, `number`, `string`, `boolean`
- Operadores: `+`, `-`, `*`, `/`, `=`, `+=`, `-=`, `==`, `!=`, `&&`, `||`

#### 2. Analisador Sintático (`bses_parser.py`)
Constrói uma Árvore de Sintaxe Abstrata (AST) a partir dos tokens.

**Estruturas AST:**
- `Program`: Nó raiz contendo todos os gameobjects
- `GameObjectDeclaration`: Definição de uma classe de jogo
- `PropertyDeclaration`: Propriedades do gameobject
- `MethodDeclaration`: Métodos do gameobject
- `Statement`: Declarações (if, while, return, etc.)
- `Expression`: Expressões (chamadas, operações, literais)

**Gramática Suportada:**
```
Program := GameObjectDeclaration*
GameObjectDeclaration := 'gameobject' IDENTIFIER '{' (PropertyDeclaration | MethodDeclaration)* '}'
PropertyDeclaration := Visibility IDENTIFIER ':' Type ('=' Expression)? ';'
MethodDeclaration := Visibility IDENTIFIER '(' ParameterList ')' (':' Type)? Block
```

#### 3. Gerador de Código (`bses_codegen.py`)
Transforma a AST em código JavaScript executável.

**Processo de Geração:**
1. Converte cada `gameobject` em uma classe JavaScript
2. Gera construtores com inicialização de propriedades
3. Traduz métodos BSES para JavaScript
4. Adiciona métodos padrão (`onDraw`) quando necessário
5. Cria código de inicialização do jogo

**Mapeamento de Tipos:**
- `Vector2` → `new Vector2(x, y)`
- `Color` → `new Color(r, g, b, a)`
- `number` → JavaScript number
- `string` → JavaScript string
- `boolean` → JavaScript boolean

#### 4. Compilador Principal (`bses_compiler.py`)
Orquestra todo o processo de compilação.

**Fluxo de Compilação:**
1. Descoberta de arquivos `.bses` no projeto
2. Análise léxica e sintática de cada arquivo
3. Geração de código JavaScript
4. Injeção do código no template HTML5
5. Criação do arquivo HTML final

#### 5. Gerador BSESK (`bsesk_generator.py`)
Sistema de geração automática usando IA da OpenAI.

**Processo BSESK:**
1. Leitura do arquivo `.bsesk` (chave API + descrição)
2. Construção de prompt especializado
3. Chamada à API da OpenAI (modelo `gpt-4.1-mini`)
4. Processamento e limpeza da resposta
5. Geração do arquivo `.bses` resultante

### Runtime JavaScript

#### Engine Core (`game_template.html`)
A engine JavaScript fornece:

**Classes Base:**
- `BSESEngine`: Loop principal do jogo
- `Vector2`, `Vector3`: Matemática vetorial
- `Color`: Representação de cores RGBA

**APIs Globais:**
- `Game`: Controle do estado do jogo
- `Input`: Gerenciamento de entrada
- `Graphics`: Funções de desenho
- `Audio`: Reprodução de som

**Sistema de Colisão:**
- Detecção AABB (Axis-Aligned Bounding Box)
- Callbacks automáticos `onCollision`

**Loop de Jogo:**
```javascript
gameLoop(currentTime) {
    // Calcular deltaTime
    // Atualizar todos os gameobjects (onUpdate)
    // Verificar colisões
    // Desenhar todos os gameobjects (onDraw)
    // Atualizar estatísticas (FPS, contadores)
}
```

## Especificação da Linguagem BSES

### Sintaxe Básica

#### Definição de GameObjects
```bses
gameobject NomeDoObjeto {
    // Propriedades
    public propriedadePublica: tipo = valorPadrao;
    private propriedadePrivada: tipo;
    
    // Construtor
    constructor(parametros: tipos) {
        // Inicialização
    }
    
    // Métodos de ciclo de vida
    public onUpdate(deltaTime: number) {
        // Lógica executada a cada frame
    }
    
    public onCollision(other: GameObject) {
        // Chamado quando há colisão
    }
    
    public onDraw(ctx: GraphicsContext) {
        // Desenho customizado (opcional)
    }
}
```

#### Tipos de Dados
- **Primitivos**: `number`, `string`, `boolean`
- **Engine**: `Vector2`, `Vector3`, `Color`
- **Coleções**: `Array`, `Map`
- **Referência**: `GameObject`

#### Operadores
- **Aritméticos**: `+`, `-`, `*`, `/`, `%`
- **Atribuição**: `=`, `+=`, `-=`, `*=`, `/=`
- **Comparação**: `==`, `!=`, `<`, `>`, `<=`, `>=`
- **Lógicos**: `&&`, `||`, `!`

### API da Engine

#### Módulo Game
```javascript
Game.instantiate(TipoObjeto, ...argumentos)  // Cria novo gameobject
Game.destroy(objeto)                         // Remove gameobject
Game.loadScene(nomeScene)                    // Carrega nova cena
```

#### Módulo Input
```javascript
Input.isPressed(tecla)           // Verifica se tecla está pressionada
Input.isJustPressed(tecla)       // Verifica se tecla foi pressionada neste frame
Input.getMousePosition()         // Retorna Vector2 com posição do mouse
```

**Teclas Suportadas:**
- Direcionais: `"up"`, `"down"`, `"left"`, `"right"`
- WASD: `"w"`, `"a"`, `"s"`, `"d"`
- Especiais: `"space"`, `"enter"`

#### Módulo Graphics
```javascript
Graphics.drawRectangle(x, y, width, height, color)
Graphics.drawCircle(x, y, radius, color)
Graphics.drawSprite(spriteName, position, size)
Graphics.drawText(text, x, y, color, size)
```

#### Módulo Audio
```javascript
Audio.playSound(nomeDoSom)
Audio.playMusic(nomeDaMusica, loop)
```

## Sistema BSESK (Kids)

### Formato do Arquivo .bsesk
```
sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Descrição do jogo em linguagem natural.
Pode ser em múltiplas linhas.
Seja específico sobre mecânicas, controles e objetivos.
```

### Prompt Engineering
O sistema BSESK usa um prompt especializado que:

1. **Contextualiza** a linguagem BSES
2. **Especifica** a sintaxe e API disponível
3. **Fornece exemplos** de código comum
4. **Instrui** sobre boas práticas
5. **Solicita** código funcional e completo

### Modelos Suportados
- `gpt-4.1-mini`: Modelo principal (rápido e eficiente)
- `gpt-4.1-nano`: Modelo alternativo (mais leve)
- `gemini-2.5-flash`: Modelo do Google (experimental)

## Extensibilidade

### Adicionando Novos Tipos
1. Adicionar token no `bses_lexer.py`
2. Atualizar parser em `bses_parser.py`
3. Implementar geração em `bses_codegen.py`
4. Adicionar classe JavaScript no template

### Adicionando Novas APIs
1. Implementar módulo JavaScript no template
2. Documentar na especificação BSES
3. Atualizar prompt do sistema BSESK

### Otimizações Futuras
- **Minificação**: Compressão do código JavaScript gerado
- **Tree Shaking**: Remoção de código não utilizado
- **Bundling**: Combinação de múltiplos arquivos
- **Source Maps**: Mapeamento para debugging
- **Hot Reload**: Recompilação automática durante desenvolvimento

## Debugging e Troubleshooting

### Erros Comuns

#### Erro de Sintaxe
```
SyntaxError: Esperado ':'. Encontrado ')' na linha X
```
**Solução**: Verificar sintaxe de declaração de propriedades e parâmetros.

#### Erro de Tipo
```
Esperado um tipo. Encontrado 'X' na linha Y
```
**Solução**: Usar tipos válidos (`number`, `string`, `Vector2`, etc.).

#### Erro de Compilação
```
Erro ao compilar arquivo.bses: ...
```
**Solução**: Verificar estrutura do gameobject e sintaxe dos métodos.

### Logs de Debug
A engine gera logs no console do navegador:
- Criação/destruição de objetos
- Eventos de colisão
- Erros de runtime
- Estatísticas de performance

### Ferramentas de Desenvolvimento
- **Console do navegador**: Para logs e debugging
- **DevTools**: Para análise de performance
- **Source inspection**: Para verificar código gerado
