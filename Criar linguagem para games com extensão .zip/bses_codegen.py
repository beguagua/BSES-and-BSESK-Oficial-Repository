'''
Gerador de Código JavaScript para BlueSoft Engine Script (BSES)
'''

from typing import List, Any
from bses_parser import *

class BSESCodeGenerator:
    def __init__(self):
        self.output = []
        self.indent_level = 0
    
    def indent(self):
        return "    " * self.indent_level

    def emit_line(self, code: str = ""):
        self.output.append(self.indent() + code)

    def increase_indent(self):
        self.indent_level += 1

    def decrease_indent(self):
        self.indent_level = max(0, self.indent_level - 1)

    def generate(self, ast: Program) -> str:
        self.output = []
        for gameobject in ast.gameobjects:
            self.generate_gameobject(gameobject)
            self.emit_line()

        self.emit_line("// Initialize game objects")
        self.emit_line("function initializeGame() {")
        self.increase_indent()

        if ast.gameobjects:
            # Heurística: Instanciar primeiro o objeto que parece ser o jogador
            player_go = next((go for go in ast.gameobjects if go.name.lower() == "player"), None)
            if player_go:
                self.instantiate_gameobject(player_go)

            # Instanciar outros objetos que não requerem parâmetros no construtor
            for go in ast.gameobjects:
                if go != player_go:
                    constructor = next((m for m in go.methods if m.name == "constructor"), None)
                    if not constructor or not constructor.parameters:
                         self.instantiate_gameobject(go)

        self.decrease_indent()
        self.emit_line("}")
        self.emit_line()
        self.emit_line("// Start the game")
        self.emit_line("initializeGame();")

        return "\n".join(self.output)

    def instantiate_gameobject(self, go: GameObjectDeclaration):
        constructor = next((m for m in go.methods if m.name == "constructor"), None)
        if constructor and constructor.parameters:
            params = []
            for param in constructor.parameters:
                if param.type == "Vector2": params.append("new Vector2(100, 100)")
                elif param.type == "number": params.append("0")
                else: params.append("null")
            params_str = ", ".join(params)
            self.emit_line(f"Game.instantiate({go.name}, {params_str});")
        else:
            self.emit_line(f"Game.instantiate({go.name});")

    def generate_gameobject(self, gameobject: GameObjectDeclaration):
        self.emit_line(f"class {gameobject.name} {{")
        self.increase_indent()

        constructor_method = next((m for m in gameobject.methods if m.name == "constructor"), None)

        if constructor_method:
            self.generate_constructor(constructor_method, gameobject)
        else:
            self.emit_line("constructor() {")
            self.increase_indent()
            for prop in gameobject.properties:
                if prop.default_value:
                    self.emit_line(f"this.{prop.name} = {self.generate_expression(prop.default_value)};")
                else:
                    self.emit_line(f"this.{prop.name} = {self.get_default_value(prop.type)};")
            self.emit_line(f"this.tag = '{gameobject.name}';")
            self.emit_line("this.size = new Vector2(32, 32);")
            self.decrease_indent()
            self.emit_line("}")
            self.emit_line()

        for method in gameobject.methods:
            if method.name != "constructor":
                self.generate_method(method)
                self.emit_line()

        if not any(m.name == "onDraw" for m in gameobject.methods):
            self.emit_line("onDraw(ctx) {")
            self.increase_indent()
            self.emit_line("if (this.position && this.size) {")
            self.increase_indent()
            self.emit_line("const color = this.color || new Color(100, 150, 255);")
            self.emit_line("Graphics.drawRectangle(this.position.x, this.position.y, this.size.x, this.size.y, color);")
            self.decrease_indent()
            self.emit_line("}")
            self.decrease_indent()
            self.emit_line("}")

        self.decrease_indent()
        self.emit_line("}")

    def generate_constructor(self, constructor: MethodDeclaration, gameobject: GameObjectDeclaration):
        params_str = ", ".join([p.name for p in constructor.parameters])
        self.emit_line(f"constructor({params_str}) {{")
        self.increase_indent()

        for prop in gameobject.properties:
            if prop.default_value:
                self.emit_line(f"this.{prop.name} = {self.generate_expression(prop.default_value)};")
            else:
                self.emit_line(f"this.{prop.name} = {self.get_default_value(prop.type)};")

        self.emit_line(f"this.tag = '{gameobject.name}';")
        self.emit_line("this.size = new Vector2(32, 32);")

        for stmt in constructor.body:
            self.generate_statement(stmt)

        self.decrease_indent()
        self.emit_line("}")
        self.emit_line()

    def generate_method(self, method: MethodDeclaration):
        params_str = ", ".join([p.name for p in method.parameters])
        self.emit_line(f"{method.name}({params_str}) {{")
        self.increase_indent()
        for stmt in method.body:
            self.generate_statement(stmt)
        self.decrease_indent()
        self.emit_line("}")

    def generate_statement(self, stmt: Statement):
        if isinstance(stmt, ExpressionStatement):
            self.emit_line(f"{self.generate_expression(stmt.expression)};")
        elif isinstance(stmt, VariableDeclaration):
            init_code = self.generate_expression(stmt.initializer) if stmt.initializer else self.get_default_value(stmt.type)
            self.emit_line(f"let {stmt.name} = {init_code};")
        elif isinstance(stmt, IfStatement):
            self.emit_line(f"if ({self.generate_expression(stmt.condition)}) {{")
            self.increase_indent()
            self.generate_statement(stmt.then_branch)
            self.decrease_indent()
            if stmt.else_branch:
                self.emit_line("} else {")
                self.increase_indent()
                self.generate_statement(stmt.else_branch)
                self.decrease_indent()
            self.emit_line("}")
        elif isinstance(stmt, WhileStatement):
            self.emit_line(f"while ({self.generate_expression(stmt.condition)}) {{")
            self.increase_indent()
            self.generate_statement(stmt.body)
            self.decrease_indent()
            self.emit_line("}")
        elif isinstance(stmt, ReturnStatement):
            self.emit_line(f"return {self.generate_expression(stmt.value) if stmt.value else ''};")
        elif isinstance(stmt, BlockStatement):
            for s in stmt.statements:
                self.generate_statement(s)

    def generate_expression(self, expr: Expression) -> str:
        if isinstance(expr, Literal):
            if expr.type == "string": return f"\'{expr.value}\'"
            if expr.type == "boolean": return "true" if expr.value else "false"
            return str(expr.value) if expr.value is not None else "null"
        if isinstance(expr, Identifier): return expr.name
        if isinstance(expr, BinaryExpression):
            return f"({self.generate_expression(expr.left)} {expr.operator} {self.generate_expression(expr.right)})"
        if isinstance(expr, UnaryExpression):
            return f"({expr.operator}{self.generate_expression(expr.operand)})"
        if isinstance(expr, AssignmentExpression):
            return f"{self.generate_expression(expr.target)} {expr.operator} {self.generate_expression(expr.value)}"
        if isinstance(expr, CallExpression):
            callee_code = self.generate_expression(expr.callee)
            args_code = [self.generate_expression(arg) for arg in expr.arguments]
            args_str = ", ".join(args_code)
            if isinstance(expr.callee, Identifier) and expr.callee.name in ["Vector2", "Vector3", "Color"]:
                return f"new {callee_code}({args_str})"
            return f"{callee_code}({args_str})"
        if isinstance(expr, MemberExpression):
            return f"{self.generate_expression(expr.object)}.{expr.property}"
        if isinstance(expr, ArrayLiteral):
            elements_str = ", ".join([self.generate_expression(e) for e in expr.elements])
            return f"[{elements_str}]"
        if isinstance(expr, ObjectLiteral):
            props_str = ", ".join([f'\"{k}\": {self.generate_expression(v)}' for k, v in expr.properties.items()])
            return f"{{{props_str}}}"
        return "null"

    def get_default_value(self, type_name: str) -> str:
        return {
            "number": "0", "string": '""', "boolean": "false",
            "Vector2": "new Vector2(0, 0)", "Vector3": "new Vector3(0, 0, 0)",
            "Color": "new Color(255, 255, 255)", "Array": "[]", "Map": "{}",
        }.get(type_name, "null")

def main():
    pass

if __name__ == "__main__":
    main()

