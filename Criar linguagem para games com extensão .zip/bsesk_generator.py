#!/usr/bin/env python3
"""
Gerador BSESK - Sistema de geração automática de jogos usando OpenAI
"""

import os
import sys
import re
from openai import OpenAI

class BSESKGenerator:
    def __init__(self):
        self.client = None
    
    def initialize_openai(self, api_key: str):
        """Inicializa o cliente OpenAI com a chave fornecida"""
        try:
            # Temporarily set the API key
            os.environ['OPENAI_API_KEY'] = api_key
            self.client = OpenAI(api_key=api_key)
            return True
        except Exception as e:
            print(f"Erro ao inicializar OpenAI: {e}")
            return False
    
    def parse_bsesk_file(self, filepath: str):
        """Lê e analisa um arquivo .bsesk"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            
            lines = content.split('\n')
            if len(lines) < 2:
                raise ValueError("Arquivo .bsesk deve conter pelo menos 2 linhas: chave API e descrição do jogo")
            
            api_key = lines[0].strip()
            description = '\n'.join(lines[1:]).strip()
            
            if not api_key.startswith('sk-'):
                raise ValueError("Primeira linha deve conter uma chave API válida da OpenAI (começando com 'sk-')")
            
            if not description:
                raise ValueError("Descrição do jogo não pode estar vazia")
            
            return api_key, description
        
        except Exception as e:
            print(f"Erro ao ler arquivo .bsesk: {e}")
            return None, None
    
    def create_game_prompt(self, description: str) -> str:
        """Cria o prompt para a OpenAI gerar o código BSES"""
        return f"""Você é um especialista em desenvolvimento de jogos usando a linguagem BlueSoft Engine Script (BSES).

ESPECIFICAÇÃO DA LINGUAGEM BSES:

1. ESTRUTURA BÁSICA:
- Jogos são compostos por gameobjects
- Cada gameobject é uma classe com propriedades e métodos
- Sintaxe similar ao TypeScript/JavaScript

2. TIPOS DE DADOS:
- number: números inteiros e decimais
- string: texto
- boolean: true/false
- Vector2: posição 2D com x,y
- Vector3: posição 3D com x,y,z  
- Color: cor RGBA
- Array: lista de valores
- Map: objeto chave-valor

3. ESTRUTURA DE GAMEOBJECT:
```bses
gameobject NomeDoObjeto {{
    public propriedade: tipo = valorPadrao;
    private propriedadePrivada: tipo;
    
    constructor(parametros) {{
        // inicialização
    }}
    
    public onUpdate(deltaTime: number) {{
        // lógica do jogo executada a cada frame
    }}
    
    public onCollision(other: GameObject) {{
        // chamado quando há colisão
    }}
    
    public onDraw(g: GraphicsContext) {{
        // desenho customizado (opcional)
    }}
}}
```

4. API GLOBAL DISPONÍVEL:
- Input.isPressed("tecla"): verifica se tecla está pressionada
- Input.getMousePosition(): posição do mouse
- Game.destroy(objeto): remove objeto do jogo
- Game.instantiate(tipo, posicao): cria novo objeto
- Graphics.drawRectangle(x, y, w, h, cor): desenha retângulo
- Graphics.drawCircle(x, y, raio, cor): desenha círculo
- print(mensagem): exibe mensagem no console

5. TECLAS DISPONÍVEIS:
- Direcionais: "up", "down", "left", "right"
- WASD: "w", "a", "s", "d"
- Espaço: "space"
- Enter: "enter"

6. EXEMPLOS DE CÓDIGO:

Movimento básico:
```bses
if (Input.isPressed("right")) {{
    this.position.x += this.speed * deltaTime;
}}
```

Criação de objetos:
```bses
let enemy = Game.instantiate(Enemy, Vector2(100, 50));
```

Colisão:
```bses
public onCollision(other: GameObject) {{
    if (other.tag == "Player") {{
        Game.destroy(this);
    }}
}}
```

TAREFA:
Baseado na descrição do jogo abaixo, gere o código BSES completo. O código deve:
- Ser funcional e executável
- Incluir todos os gameobjects necessários
- Implementar a mecânica descrita
- Usar as APIs disponíveis corretamente
- Ter lógica de jogo interessante

DESCRIÇÃO DO JOGO:
{description}

RESPOSTA:
Gere apenas o código BSES, sem explicações adicionais. O código deve estar pronto para ser compilado e executado."""

    def generate_bses_code(self, description: str) -> str:
        """Gera código BSES usando a OpenAI"""
        if not self.client:
            raise Exception("Cliente OpenAI não inicializado")
        
        prompt = self.create_game_prompt(description)
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4.1-mini",
                messages=[
                    {"role": "system", "content": "Você é um especialista em desenvolvimento de jogos e programação."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
                temperature=0.7
            )
            
            generated_code = response.choices[0].message.content.strip()
            
            # Clean up the response - remove markdown code blocks if present
            if generated_code.startswith('```'):
                lines = generated_code.split('\n')
                # Remove first and last lines if they're markdown
                if lines[0].startswith('```'):
                    lines = lines[1:]
                if lines and lines[-1].startswith('```'):
                    lines = lines[:-1]
                generated_code = '\n'.join(lines)
            
            return generated_code
            
        except Exception as e:
            raise Exception(f"Erro ao gerar código com OpenAI: {e}")
    
    def process_bsesk_file(self, input_file: str, output_file: str = None) -> bool:
        """Processa um arquivo .bsesk e gera o código .bses correspondente"""
        
        # Parse the .bsesk file
        api_key, description = self.parse_bsesk_file(input_file)
        if not api_key or not description:
            return False
        
        print(f"Processando arquivo: {input_file}")
        print(f"Descrição do jogo: {description[:100]}...")
        
        # Initialize OpenAI
        if not self.initialize_openai(api_key):
            return False
        
        print("Gerando código do jogo com IA...")
        
        try:
            # Generate BSES code
            bses_code = self.generate_bses_code(description)
            
            # Determine output file name
            if not output_file:
                base_name = os.path.splitext(input_file)[0]
                output_file = base_name + '.bses'
            
            # Save the generated code
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(bses_code)
            
            print(f"Código gerado com sucesso: {output_file}")
            return True
            
        except Exception as e:
            print(f"Erro durante a geração: {e}")
            return False
        
        finally:
            # Clean up the API key from environment
            if 'OPENAI_API_KEY' in os.environ:
                del os.environ['OPENAI_API_KEY']

def main():
    if len(sys.argv) < 2:
        print("Uso: python bsesk_generator.py <arquivo.bsesk> [arquivo_saida.bses]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    if not os.path.exists(input_file):
        print(f"Arquivo não encontrado: {input_file}")
        sys.exit(1)
    
    if not input_file.endswith('.bsesk'):
        print("Arquivo deve ter extensão .bsesk")
        sys.exit(1)
    
    generator = BSESKGenerator()
    success = generator.process_bsesk_file(input_file, output_file)
    
    if success:
        print("Geração concluída com sucesso!")
        sys.exit(0)
    else:
        print("Falha na geração do código.")
        sys.exit(1)

if __name__ == "__main__":
    main()
